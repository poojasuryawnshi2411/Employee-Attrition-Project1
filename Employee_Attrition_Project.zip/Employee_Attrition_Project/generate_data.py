"""
Generates a synthetic Employee Attrition dataset that mirrors the structure
and general statistical patterns of the well-known IBM HR Analytics Employee
Attrition & Performance dataset (Kaggle).

NOTE: This is SAMPLE / SYNTHETIC data generated for development and demo
purposes only, since the real Kaggle CSV was not available in this session.
To use the real dataset instead:
  1. Download "WA_Fn-UseC_-HR-Employee-Attrition.csv" from
     https://www.kaggle.com/datasets/pavansubhasht/ibm-hr-analytics-attrition-dataset
  2. Rename it to employee_attrition_data.csv (same columns used below)
  3. Replace this file in the project folder - no other code needs to change.
"""

import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 1470  # same size as the real IBM dataset

departments = ["Sales", "Research & Development", "Human Resources"]
dept_probs = [0.35, 0.55, 0.10]

job_roles = {
    "Sales": ["Sales Executive", "Sales Representative", "Manager"],
    "Research & Development": [
        "Research Scientist", "Laboratory Technician", "Manufacturing Director",
        "Research Director", "Healthcare Representative",
    ],
    "Human Resources": ["Human Resources", "Manager"],
}

business_travel = ["Non-Travel", "Travel_Rarely", "Travel_Frequently"]
bt_probs = [0.10, 0.70, 0.20]

marital_status = ["Single", "Married", "Divorced"]
ms_probs = [0.33, 0.46, 0.21]

education_field = ["Life Sciences", "Medical", "Marketing", "Technical Degree", "Other", "Human Resources"]

data = {
    "Age": rng.integers(18, 61, N),
    "Gender": rng.choice(["Male", "Female"], N, p=[0.6, 0.4]),
    "MaritalStatus": rng.choice(marital_status, N, p=ms_probs),
    "Department": rng.choice(departments, N, p=dept_probs),
    "BusinessTravel": rng.choice(business_travel, N, p=bt_probs),
    "EducationField": rng.choice(education_field, N),
    "Education": rng.integers(1, 6, N),                     # 1-5
    "DistanceFromHome": rng.integers(1, 30, N),
    "MonthlyIncome": rng.integers(1009, 20000, N),
    "NumCompaniesWorked": rng.integers(0, 10, N),
    "TotalWorkingYears": rng.integers(0, 41, N),
    "YearsAtCompany": rng.integers(0, 41, N),
    "YearsInCurrentRole": rng.integers(0, 19, N),
    "TrainingTimesLastYear": rng.integers(0, 7, N),
    "JobSatisfaction": rng.integers(1, 5, N),                # 1-4
    "EnvironmentSatisfaction": rng.integers(1, 5, N),        # 1-4
    "WorkLifeBalance": rng.integers(1, 5, N),                # 1-4
    "JobInvolvement": rng.integers(1, 5, N),                 # 1-4
    "PerformanceRating": rng.choice([3, 4], N, p=[0.85, 0.15]),
    "OverTime": rng.choice(["Yes", "No"], N, p=[0.28, 0.72]),
}

df = pd.DataFrame(data)

# YearsAtCompany can't exceed TotalWorkingYears - keep it consistent
df["YearsAtCompany"] = df[["YearsAtCompany", "TotalWorkingYears"]].min(axis=1)
df["YearsInCurrentRole"] = df[["YearsInCurrentRole", "YearsAtCompany"]].min(axis=1)

df["JobRole"] = df["Department"].apply(lambda d: rng.choice(job_roles[d]))

# ---- Build a realistic latent "risk score" that drives Attrition ----
risk = (
      1.4 * (df["OverTime"] == "Yes").astype(int)
    + 0.9 * (df["BusinessTravel"] == "Travel_Frequently").astype(int)
    + 0.6 * (df["MaritalStatus"] == "Single").astype(int)
    - 0.00012 * df["MonthlyIncome"]
    - 0.35 * (df["JobSatisfaction"] - 2.5)
    - 0.35 * (df["WorkLifeBalance"] - 2.5)
    - 0.25 * (df["EnvironmentSatisfaction"] - 2.5)
    - 0.05 * df["YearsAtCompany"]
    + 0.03 * df["DistanceFromHome"]
    - 0.02 * (df["Age"] - 35)
    + 0.10 * df["NumCompaniesWorked"]
    + rng.normal(0, 0.9, N)                                   # noise
)

prob_attrition = 1 / (1 + np.exp(-(risk - 1.7)))              # logistic squashing
df["Attrition"] = (rng.random(N) < prob_attrition).map({True: "Yes", False: "No"})

# Reorder columns to a friendly, report-style order
column_order = [
    "Age", "Gender", "MaritalStatus", "Department", "JobRole", "EducationField",
    "Education", "BusinessTravel", "DistanceFromHome", "MonthlyIncome",
    "NumCompaniesWorked", "TotalWorkingYears", "YearsAtCompany", "YearsInCurrentRole",
    "TrainingTimesLastYear", "JobSatisfaction", "EnvironmentSatisfaction",
    "WorkLifeBalance", "JobInvolvement", "PerformanceRating", "OverTime", "Attrition",
]
df = df[column_order]

out_path = "employee_attrition_data.csv"
df.to_csv(out_path, index=False)
print(f"Saved {len(df)} rows to {out_path}")
print(df["Attrition"].value_counts(normalize=True).mul(100).round(1))
