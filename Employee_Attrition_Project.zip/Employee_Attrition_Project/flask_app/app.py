"""
Flask web application for the "Predicting Employee Attrition Using
Classification Algorithms" project.

Run with:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000 in your browser.
"""

import joblib
import pandas as pd
from flask import Flask, render_template, request

app = Flask(__name__)

# ---- Load trained artifacts (produced by the Jupyter notebook) ----
model = joblib.load("attrition_model.pkl")
scaler = joblib.load("scaler.pkl")
FEATURE_COLUMNS = joblib.load("feature_columns.pkl")


def build_feature_row(form):
    """Turns the raw HTML form values into the exact one-hot encoded row
    the model was trained on."""
    row = {col: 0 for col in FEATURE_COLUMNS}

    # --- numeric / ordinal fields ---
    row["Age"] = float(form["age"])
    row["MonthlyIncome"] = float(form["monthly_income"])
    row["DistanceFromHome"] = float(form["distance_from_home"])
    row["YearsAtCompany"] = float(form["years_at_company"])
    row["TotalWorkingYears"] = float(form["total_working_years"])
    row["NumCompaniesWorked"] = float(form["num_companies_worked"])
    row["JobSatisfaction"] = float(form["job_satisfaction"])
    row["EnvironmentSatisfaction"] = float(form["environment_satisfaction"])
    row["WorkLifeBalance"] = float(form["work_life_balance"])
    row["JobInvolvement"] = float(form["job_involvement"])

    # --- one-hot categorical fields (base/reference category = 0) ---
    if form["overtime"] == "Yes" and "OverTime_Yes" in row:
        row["OverTime_Yes"] = 1

    business_travel = form["business_travel"]
    if business_travel == "Travel_Frequently" and "BusinessTravel_Travel_Frequently" in row:
        row["BusinessTravel_Travel_Frequently"] = 1
    elif business_travel == "Travel_Rarely" and "BusinessTravel_Travel_Rarely" in row:
        row["BusinessTravel_Travel_Rarely"] = 1
    # "Non-Travel" is the reference category -> both stay 0

    department = form["department"]
    if department == "Research & Development" and "Department_Research & Development" in row:
        row["Department_Research & Development"] = 1
    elif department == "Sales" and "Department_Sales" in row:
        row["Department_Sales"] = 1
    # "Human Resources" is the reference category -> both stay 0

    marital_status = form["marital_status"]
    if marital_status == "Married" and "MaritalStatus_Married" in row:
        row["MaritalStatus_Married"] = 1
    elif marital_status == "Single" and "MaritalStatus_Single" in row:
        row["MaritalStatus_Single"] = 1
    # "Divorced" is the reference category -> both stay 0

    if form["gender"] == "Male" and "Gender_Male" in row:
        row["Gender_Male"] = 1

    return pd.DataFrame([row])[FEATURE_COLUMNS]


@app.route("/", methods=["GET"])
def home():
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    input_df = build_feature_row(request.form)
    input_scaled = pd.DataFrame(
        scaler.transform(input_df), columns=FEATURE_COLUMNS
    )

    prediction = model.predict(input_scaled)[0]
    probability = model.predict_proba(input_scaled)[0][1]  # P(Attrition = Yes)

    result = {
        "prediction": "Yes - Likely to Leave" if prediction == 1 else "No - Likely to Stay",
        "probability": round(probability * 100, 1),
        "risk_level": "High" if probability >= 0.6 else ("Medium" if probability >= 0.3 else "Low"),
    }
    return render_template("result.html", result=result, form=request.form)


if __name__ == "__main__":
    app.run(debug=True)
